var monkeyList = new List('test-list', {
    valueNames: ['name'],
    page: 2,
    plugins: [ ListPagination({}) ]
});